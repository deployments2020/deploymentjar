package com.tibco.integrationframework.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import com.tibco.integrationframework.model.InterfaceDeploymentDetails;

import java.util.List;

@Repository
@RepositoryRestResource(collectionResourceRel = "deploymentDetails", path = "/api/v1")
public interface DeploymentDetailsRepository extends MongoRepository<InterfaceDeploymentDetails, String>{

    List<InterfaceDeploymentDetails> findAll();

    InterfaceDeploymentDetails findByProjectId(Integer projectId);

}
