package com.tibco.integrationframework.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Interface_Deployment_Details")
public class InterfaceDeploymentDetails {
	
	@Id
	private String id;
	@Field(value = "Project_ID")
	private int projectId;
	@Field(value = "Interface_Name")
	private String interfaceName;
	@Field(value = "Deployment_Mode")
	private String deploymentMode;

	public InterfaceDeploymentDetails() {
		
	}

	public InterfaceDeploymentDetails(String id, int projectId, String interfaceName, String deploymentMode) {
		this.id = id;
		this.projectId = projectId;
		this.interfaceName = interfaceName;
		this.deploymentMode = deploymentMode;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getInterfaceName() {
		return interfaceName;
	}

	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}

	public String getDeploymentMode() {
		return deploymentMode;
	}

	public void setDeploymentMode(String deploymentMode) {
		this.deploymentMode = deploymentMode;
	}

	@Override
	public String toString() {
		return "DeploymentDetails{" +
				"id=" + id +
				", projectId=" + projectId +
				", interfaceName='" + interfaceName + '\'' +
				", deploymentMode='" + deploymentMode + '\'' +
				'}';
	}
}
