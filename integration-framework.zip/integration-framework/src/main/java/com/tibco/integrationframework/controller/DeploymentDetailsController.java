package com.tibco.integrationframework.controller;

import com.tibco.integrationframework.exception.ResourceNotFoundException;
import com.tibco.integrationframework.repository.DeploymentDetailsRepository;
import com.tibco.integrationframework.model.InterfaceDeploymentDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/api/v1")
public class DeploymentDetailsController {


    @Autowired
    private DeploymentDetailsRepository deploymentDetailsRepository;

    @GetMapping("/deploymentDetails")
    public ResponseEntity<List<InterfaceDeploymentDetails>>  getAllDetails() {

        List<InterfaceDeploymentDetails> details = deploymentDetailsRepository.findAll();

        return new ResponseEntity<>(details, HttpStatus.OK);
    }

    @GetMapping("/deploymentDetails/{projectId}")
    public ResponseEntity<InterfaceDeploymentDetails> getDetailsByProjectId(@PathVariable(value = "projectId") int projectId)
            throws ResourceNotFoundException {

        InterfaceDeploymentDetails deploymentDetails = deploymentDetailsRepository.findByProjectId(projectId);

        return ResponseEntity.ok().body(deploymentDetails);
    }
}
